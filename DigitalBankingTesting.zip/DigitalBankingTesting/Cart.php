<?php
class Cart
{
    public $price;
    public static $discount=0.2;
    public function getNetPrice(){
        return $this->price-$this->price*self::$discount;
    }

}
?>