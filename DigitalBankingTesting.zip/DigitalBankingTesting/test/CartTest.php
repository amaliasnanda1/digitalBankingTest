<?php
class CarTest extends \PHPUnit\Framework\TestCase{
    public function testNetPriceIsCorrect(){
        require "Cart.php";
        $cart = new CartTest();
        $cart->price = 1000;
        self::assertEquals(800,$cart->getNetPrice());
    }
}
?>