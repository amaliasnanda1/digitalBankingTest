<?php

class FirstTest extends \PHPUnit\Framework\TestCase
{
    public function testMultiplicationIsCorrect()
    {
        self::assertEquals(10,2*5);
    }
    public function testPasswordIsInDB(){
        $enteredPass="Smith";
        $passInDB="John";
        self::assertSame($enteredPass,$passInDB);
    }

}
?>